<?php
	include("config.php");
	session_start();
	$id = $_SESSION['id'];
	if(is_null($id)){header('location: login.php');}
	$query = pg_query("SELECT * FROM userr where username = '$id'");
	
	$saldo = pg_fetch_array($query, NULL, PGSQL_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Hedon(Hemat Dong)|Pencatat Pengeluaran Pegawai</title>
</head>

<body>
	<header>
		<h1 >Welcome <?= $saldo['nama']?> 
		<br> Bendahara <?= $saldo['nama_acara']?> </br> </h1>
	</header>
	<h4  >Menu</h4>
	<nav>
		<ul>
			<li ><a href="formsaldo.php?username=<?= $saldo['username']?>">Update Saldo</a></li>
			<li><a href="formtransaksi.php?username=<?=$saldo['username']?>">Tambah Transaksi</a></li>
			<li><a href="formsaldo.php">Lihat Rekapan
				<ul>
      				<li><a href="viewtr.php?username=<?= $saldo['username']?>">Transaksi</a></li>
      				<li><a href="viewinv.php?username=<?= $saldo['username']?>">Inventaris</a></li>
        		</ul>
    			</ul>
			</a></li>
		</ul>
	</nav>


	<?php if(isset($_GET['status'])): ?>
	<p>
		<?php
			if($_GET['status'] == 'sukses'){
				echo "Update saldo berhasil!";
			} else {
				echo "Update saldo gagal!";
			}
		?>
	</p>
	<?php endif; ?>
	<?php if(isset($_GET['status1'])): ?>
	<p>
		<?php
			if($_GET['status1'] == 'sukses'){
				echo "Tambah transaksi berhasil!";
			} else {
				echo "Tambah transaksi gagal!";
			}
		?>
	</p>
	<?php endif; ?>

	<button><a href="logout.php">Logout</a></button>
	</body>
</html>
