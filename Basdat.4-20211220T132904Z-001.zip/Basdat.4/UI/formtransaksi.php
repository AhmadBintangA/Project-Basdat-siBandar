<?php
include("config.php");
	session_start();
	if(!isset($_SESSION['login']))
	{
		header('location:login.php');
	}

if (isset($_GET['username'])) {
    $id = $_GET['username'];
} else {
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/edit</title>
</head>
<body>
    <header>
    <h3>Formulir Transaksi</h3>
    </header>
    <form action="prosestransaksi.php" method="POST">
		<fieldset>
		<p>
			
			<input type="hidden" name="kode_transaksi" value=<?= rand(1, 1000000) ?> placeholder="Masukkan Kode Transaksi" />
		</p>
        <p>
			<label for="nama_pj">Nama Penanggung Jawab : </label>
			<input type="text" name="nama_pj" placeholder="Nama PJ" />
		</p>
		<p>
			<label for="jabatan">Jabatan : </label>
			<input type="text" name="jabatan" placeholder="Nama Jabatan" />
		</p>
		<p>
			<label for="nama_transaksi">Nama Transaksi : </label>
			<input type="text" name="nama_transaksi" placeholder="Nama Transaksi" />
		</p>
        <p>
			<label for="tanggal_transaksi">Tanggal Transaksi : </label>
			<input type="date" name="tanggal_transaksi" placeholder="dd/mm/yy" />
		</p>
		<p>
            <input type="hidden" name="username" value="<?= $id?>"   /> 
        </p>
		<p>
			
			<input type="hidden" name="kode_item" value=<?= rand(1, 1000000) ?> placeholder="Kode Item" />
		</p>
		<p>
			<label for="nama_barang">Nama Barang : </label>
			<input type="text" name="nama_barang" placeholder="Nama Barang" />
		</p>
		<p>
			<label for="jumlah">Jumlah Barang : </label>
			<input type="number" name="jumlah" placeholder="Jumlah Barang" />
		</p>		
		<p>
			<label for="jenis_item">Jenis Item : </label>
			<label><input type="radio" name="jenis_item" value="awet"> Awet</label>
			<label><input type="radio" name="jenis_item" value="abis"> Abis</label>
	
		</p>
		<p>
			<label for="harga">Harga : </label>
			<input type="number" name="harga" placeholder="Masukkan harga" />
		</p>
		
		<p>
			<input type="submit" value="Tambah" name="Tambah" />
		</p>
		
		</fieldset>
	
	</form>
<a href="index.php">Back</a>
</body>
</html>