<!DOCTYPE html>
<html>

<head>
	<title>Si Bandar</title>
	<link href='gambar-burung-garuda-asli.jpg' rel='shortcut icon'>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<style>
		.mx-auto 
		{
			width: 1000px;
			margin: 50px;
		}
		.mx-auto2 
		{
			padding: 15px;
			
		}
	</style>
</head>

<body>
	<div class="mx-auto">
		<div class="card">
			<div class="card-header fw-bold bg-primary fs-2">
				Formulir Mahasiswa
			</div>
			<div class="card-body">
				<form action="prosestransaksi.php" method="POST">
					<div class="mb-3 row">
						<label for="kode_transaksi" class="col-sm-2 col-form-label">Kode Transaksi</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="nim" name="Nomor Induk Mahasiswa" placeholder="Masukkan Kode">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="nama_pj" class="col-sm-2 col-form-label">Nama Penanggung Jawab</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="nim" name="Nomor Induk Mahasiswa" placeholder="Masukkan Kode">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="jabatan" class="col-sm-2 col-form-label">Jabatan</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="jabatan" name="Jabatan" placeholder="Nama Jabatan">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="nama_transaksi" class="col-sm-2 col-form-label">Nama Transaksi</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="nama_transaksi" name="Nama Transaksi" placeholder="Nama Transaksi">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="tanggal_transaksi" class="col-sm-2 col-form-label">Tanggal Transaksi</label>
						<div class="col-sm-10">
							<input type="date" class="form-control" id="tanggal_transaksi" name="tanggal_transaksi" placeholder="dd/mm/yy">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="kode_item" class="col-sm-2 col-form-label">Kode Item</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="kode_item" name="Kode Item" placeholder="Masukkan Kode Item">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="nama_barang" class="col-sm-2 col-form-label">Nama Barang</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="nama_barang" name="Nama Barang" placeholder="Nama Barang">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="jenis_item" class="col-sm-2 col-form-label">Jenis Item</label>
						<div class="col-sm-10">
							<select class="form-control" id="jenis_item">
								<option value="">- Pilih Item -</option>
								<option value="Awet">Awet</option>
								<option value="Habis">Habis</option>
							</select>
						</div>
					</div>
					<div class="mb-3 row">
						<label for="harga" class="col-sm-2 col-form-label">Harga</label>
						<div class="col-sm-10">
							<input type="number" class="form-control" id="harga" name="Harga" placeholder="Masukkan Harga">
						</div>
					</div>
					<div class="d-grid gap-2 d-md-flex justify-content-md-end">
						<button class="btn btn-primary me-md-2" type="Submit" value="Tambah">Tambah</button>
					</div>
			</div>
		</div>

		</form>
		<div class="mx-auto2"><a class="btn btn-primary" href="index.php" role="button">Kembali</a>
		</div>
</body>
</html>