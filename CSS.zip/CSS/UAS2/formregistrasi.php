<!DOCTYPE html>
<html>

<head>
	<title>Si Bandar</title>
	<link href='gambar-burung-garuda-asli.jpg' rel='shortcut icon'>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<style>
		.mx-auto {
			width: 1000px;
			margin: 50px;
		}

		.mx-auto2 {
			padding: 15px;

		}
	</style>
</head>

<body>
	<div class="mx-auto">
		<div class="card">
			<div class="card-header fw-bold bg-primary fs-2">
				Formulir Mahasiswa
			</div>
			<div class="card-body">
				<form action="prosesregistrasi.php" method="POST">
					<div class="mb-3 row">
						<label for="username" class="col-sm-2 col-form-label">Username</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="username" name="username" placeholder="Masukkan Username">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="password" class="col-sm-2 col-form-label">Password</label>
						<div class="col-sm-10">
							<input type="password" class="form-control" id="password" name="Password" placeholder="Masukkan Password">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="nama" class="col-sm-2 col-form-label">Nama</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="nama" name="Nama" placeholder="Masukkan Nama">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="nama_acara" class="col-sm-2 col-form-label">Nama Acara/Organisasi</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="nama_acara" name="Nama Acara/Organisasi" placeholder="Masukkan Acara/Organisasi">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="jumlah_saldo" class="col-sm-2 col-form-label">Jumlah Saldo</label>
						<div class="col-sm-10">
							<input type="number" class="form-control" id="jumlah_saldo" name="Jumlah Saldo" placeholder="Masukkan Saldo">
						</div>
					</div>
					<div class="mb-3 row">
						<label for="tanggal_masuk" class="col-sm-2 col-form-label">Tanggal Masuk</label>
						<div class="col-sm-10">
							<input type="date" class="form-control" id="tanggal_masuk" name="Tanggal Masuk" placeholder="dd/mm/yy">
						</div>
					</div>
					<div class="d-grid gap-2 d-md-flex justify-content-md-end">
						<button class="btn btn-primary me-md-2" type="Submit" value="Regist" name="Regist">Register</button>
					</div>
				</form>
				<div class="mx-auto2"><a class="btn btn-primary" href="index.php" role="button">Kembali</a>
	</div>
</body>

</html>