<!DOCTYPE html>
<html>

<head>
	<title>Si Bandar</title>
	<link href='gambar-burung-garuda-asli.jpg' rel='shortcut icon'>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<style>
		.mx-auto {
			width: 1000px;
			margin: 50px;
		}
		
	</style>
</head>

<body>
		<header>
			<h1>Welcome Bendahara </h1>
		</header>
		<h4>Menu</h4>
		<nav>
			<ul>
				<li><a href="formsaldo.php">Update Saldo</a></li>
				<li><a href="formtransaksi.php">Tambah Transaksi</a></li>
				<li><a href="formsaldo.php">Lihat Rekapan
						<ul>
							<li><a href="formsaldo.php    ">Transaksi</a></li>
							<li><a href="formsaldo.php    ">Inventaris</a></li>
						</ul>
			</ul>
			</a></li>
			</ul>
		</nav>




		<button><a href="logout.php">Logout</a></button>
</body>

</html>