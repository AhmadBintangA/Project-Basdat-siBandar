<!DOCTYPE html>
<html>
<head>
	<title>Si Bandar</title>
	<link rel="stylesheet" href="style.css">
</head>

<body>
		<header>
			<h1>Welcome</h1>
			<h3>SI BANDAR <br />
				Si Pembantu Bendahara
		</h3>
		
		</header>

		<h4>Menu</h4>
		<nav>
			<ul>
				<li><a href="formdaftar.php">Daftar Baru</a></li>
				<li><a href="daftarsiswa.php">Daftar Mahasiswa</a></li>
			</ul>
		</nav>


		<?php if(isset($_GET['status'])): ?>
		<p>
			<?php
				if($_GET['status'] == 'sukses'){
					echo "Pendaftaran baru berhasil!";
				} else {
					echo "Pendaftaran gagal!";
				}
			?>
		</p>
		<?php endif; ?>
	</body>
</html>
