<!DOCTYPE html>
<html>
<head>
	<title>Si Bandar</title>
	<link rel="stylesheet" href="style.css">
</head>

<body>
		<div class="wrap">
		<div class="container">
		<header>
			<h1>Formulir Mahasiswa</h1>
		</header>

		<form action="prosespendaftaran.php" method="POST">
			<table>
			<tr>
				<td> NIM</td>
				<td>:</td>
				<td><input type="text" name="nim" placeholder="Masukkan NIM"></td>
			</tr>
			<tr>
			<td> Nama</td>
				<td>:</td>
				<td><input type="text" name="nama" placeholder="Masukkan Nama Lengkap"></td>
			</tr>
			<tr>
			<td> Jenis kelamin</td>
				<td>:</td>
				<td>
					<input type="radio" name="jenis_kelamin" value="laki-laki"> Laki-laki
					<input type="radio" name="jenis_kelamin" value="perempuan"> Perempuan
				</td>
			</tr>
			<tr>
			<td> Asal Daerah</td>
				<td>:</td>
				<td><input type="text" name="asal_daerah" placeholder="Asal Daerah"></td>
			</tr>
			<tr>
			<td> Kode Saldo</td>
				<td>:</td>
				<td><input type="text" name="kode_saldo" placeholder="Kode Anda 10 digit"></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>
				<button type="submit" name="Masuk">Masuk</button>
			</td>
			</table>
		</form>
		<button><a href="index.php">Back<a></button>
	</div>
</body>
</html>
