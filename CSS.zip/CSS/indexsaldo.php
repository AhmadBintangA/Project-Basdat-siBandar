<!DOCTYPE html>
<html>
<head>
	<title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa</title>
</head>

<body>
	<header>
		<h3>Saldo
	</h3>
	
	</header>

	<h4>Tambah atau Lihat</h4>
	<nav>
		<ul>
			<li><a href='formsaldo.php'>Tambah Saldo</a></li>
			<li><a href='formsaldo.php'>Lihat Saldo</a></li>
		</ul>
	</nav>


	<?php if(isset($_GET['status'])): ?>
	<p>
		<?php
			if($_GET['status'] == 'sukses'){
				echo "Saldo baru berhasil!";
			} else {
				echo "Saldo gagal!";
			}
		?>
	</p>
	<?php endif; ?>

	</body>
</html>
