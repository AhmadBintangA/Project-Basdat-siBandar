<?php
include("config.php");
if (isset($_GET['kode_saldo'])) {
    $id = $_GET['kode_saldo'];
} else {
    header('Location: daftarsiswa.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/edit</title>
</head>
<body>
    <header>
    <h3>Formulir Transaksi si hedon</h3>
    </header>
    <form action="prosestransaksi.php" method="POST">
		<fieldset>
        <p>
            <input type="hidden" name="kode_saldo" value="<?= $id?>"   /> 
        </p>
		<p>
			<label for="kode_transaksi">Kode Transaksi : </label>
			<input type="text" name="kode_transaksi" placeholder="Masukkan Kode Transaksi" />
		</p>
        <p>
			<label for="nama_transaksi">Nama Transaksi : </label>
			<input type="text" name="nama_transaksi" placeholder="Nama Transaksi" />
		</p>
        <p>
			<label for="tanggal_transaksi">Tanggal Transaksi : </label>
			<input type="date" name="tanggal_transaksi" placeholder="dd/mm/yy" />
		</p>
		<p>
			<input type="submit" value="Tambah" name="Tambah" />
		</p>
		
		</fieldset>
	
	</form>
<a href="daftarsiswa.php">Back</a>
</body>
</html>