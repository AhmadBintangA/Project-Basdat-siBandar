<?php
include("config.php");
// cek apakah tombol daftar sudah diklik atau blum?
if (isset($_POST['Masuk'])) {

        $id = $_POST['kode_saldo'];
        $nim = $_POST['nim'];
	    $nama = $_POST['nama'];
	    $jk = $_POST['jenis_kelamin'];
	    $asal = $_POST['asal_daerah'];

        // buat query
        $q = "UPDATE mahasiswa SET nim='$nim', nama='$nama', jenis_kelamin='$jk', asal_daerah='$asal' WHERE kode_saldo = '$id'";
        $query = pg_query($q);
        // apakah query simpan berhasil?
        if ($query) {
            // kalau berhasil alihkan ke halaman index.php dengan status=sukses
            header('Location: daftarsiswa.php?status=sukses&action=edit');
        } else {
            // kalau gagal alihkan ke halaman indek.ph dengan status=gagal
            header('Location: daftarsiswa.php?status=gagal&action=edit');
        }
    

    // ambil data dari formulir
}


else {
    die("Akses dilarang...");
}
