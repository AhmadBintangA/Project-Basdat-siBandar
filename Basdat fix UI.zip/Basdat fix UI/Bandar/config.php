<?php
$db=pg_connect('host=localhost dbname=bandar user=postgres password=001485');
if( !$db ){
    die("Gagal terhubung dengan database: " . pg_connect_error());
}
?>
<?php
date_default_timezone_set("Asia/jakarta"); ?>
