<?php
include("config.php");
if(isset($_GET['username'])){
    $id = $_GET['username'];
    $kode=$_GET['kode_transaksi'];

    $query = pg_query("DELETE FROM transaksi WHERE username='$id' AND kode_transaksi='$kode'");
    if($query){
        $query2 = pg_query("DELETE FROM item WHERE username='$id' AND kode_transaksi='$kode'");
        
        header("Location: viewtr.php?username=$id");
        //header('Location: viewtr.php');
    }
    else{
        die("gagal menghapus...");
    }
} else{
    die("akses dilarang...");
}
?>