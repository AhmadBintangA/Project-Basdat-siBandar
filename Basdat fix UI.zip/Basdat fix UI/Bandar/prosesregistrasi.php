<?php
include("config.php");
// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['Regist'])){

	// ambil data dari formulir
    $username = strtolower($_POST['username']);
	$pass = $_POST['pass'];
	$nama = $_POST['nama'];
	$acara = $_POST['nama_acara'];
	$mjab= $_POST['masa_jabatan'];
	$saldo = $_POST['jumlah_saldo'];
	$tgl = $_POST['tanggal_masuk'];
	
	

	// buat query
  $query = pg_query("INSERT INTO userr(username, pass, nama, nama_acara,masa_jabatan) VALUES ('$username', '$pass', '$nama', '$acara','$mjab')");
  if($query){
	$query1 = pg_query("INSERT INTO saldo(username,jumlah_saldo,tanggal_masuk) VALUES ('$username', '$saldo', '$tgl')");
	header('Location: login.php?status=sukses');
  }


	// apakah query simpan berhasil
		// kalau berhasil alihkan ke halaman index.php dengan status=sukses
	else {
		// kalau gagal alihkan ke halaman indek.ph dengan status=gagal
		header('Location: index.php?status=gagal');
	}


} else {
	die("Akses dilarang...");
}
?>
