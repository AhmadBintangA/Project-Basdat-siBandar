<?php
include("config.php");
// cek apakah tombol masuk sudah diklik atau blum?
if (isset($_POST['Simpan'])) {
	if (isset($_GET['id'])) {
	$id = $_GET['id'] ;
	$kode = $_POST['kode_saldo'] ;
    $jumlah_saldo = $_POST['jumlah_saldo'];
	$tanggal = $_POST['tanggal_masuk'];
	// buat query
    
	$q = "UPDATE saldo SET kode_saldo='$kode', jumlah_saldo='$jumlah_saldo', tanggal_masuk='$tanggal' WHERE id = '$id'";
	$query = pg_query($q);
	// apakah query simpan berhasil?
	if( $query==TRUE ) {
		// kalau berhasil alihkan ke halaman index.php dengan status=sukses
		header('Location: index.php?status=sukses');
	} else {
		// kalau gagal alihkan ke halaman indek.ph dengan status=gagal
		header('Location: index.php?status=gagal');
	}

	} 
}
else {
	die("Akses saldo dilarang...");
}


