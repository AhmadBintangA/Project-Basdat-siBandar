<?php
include("config.php");
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $NIM = $_GET['nim'];
    $query = pg_query("DELETE FROM mahasiswa WHERE id=$id");
    $query1 = pg_query("DELETE FROM saldo WHERE id=$id");
    if ($query){
        header('Location: daftarsiswa.php');
    } else{
        die("gagal mengahpus...");
    }
} else{
    die("akses dilarang...");
}
?>