<?php
include("config.php");
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = pg_query($db, "SELECT * FROM mahasiswa WHERE id = $id");
    $siswa = pg_fetch_array($query, NULL, PGSQL_ASSOC);
} else {
    header('Location: daftarsiswa.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/edit</title>
</head>
<body>
    <header>
        <h3>Formulir edit si hedon</h3>
    </header>
    <form action="prosesedit.php?id=<?=$siswa['id']?>" method="POST">
        <fieldset>
            <p>
                <label for="nim">NIM: </label>
                <input type="text" name="nim" placeholder="Masukkan NIM" value="<?= $siswa['nim'] ?>" />
            </p>
            <p>
                <label for="nama">Nama: </label>
                <input type="text" name="nama" placeholder="Masukkan Nama Lengkap" value="<?= $siswa['nama'] ?>" />
            </p>
            <p>
                <label for="jenis_kelamin">Jenis Kelamin: </label>
                <label><input type="radio" name="jenis_kelamin" value="laki-laki" 
                <?php
                    if ($siswa['jenis_kelamin'] == 'laki-laki') {
                        echo "checked";
                    }
                ?>> Laki-laki</label>
                <label><input type="radio" name="jenis_kelamin" 
                <?php
                    if ($siswa['jenis_kelamin'] == 'perempuan') {
                        echo "checked";
                    }
                   ?> value="perempuan"> Perempuan</label>
            </p>
            <p>
                <label for="asal_daerah">Asal Daerah: </label>
                <input type="text" name="asal_daerah" placeholder="nama sekolah" value="<?= $siswa['asal_daerah'] ?>" />
            </p>
            <p>
                <input type="submit" value="Edit" name="Masuk" />
            </p>
        </fieldset>
    </form>
    <a href="daftarsiswa.php">Back</a>
</body>
</html>