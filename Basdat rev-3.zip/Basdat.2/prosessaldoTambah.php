<?php
include("config.php");
// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['Save'])){
    
    //ambil data dari formulir
    $kode = $_POST['kode_saldo'] ;
    $jumlah_saldo = $_POST['jumlah_saldo'];
    $tanggal = $_POST['tanggal_masuk'];
	

	// buat query
  $query = pg_query("INSERT INTO saldo(kode_saldo, jumlah_saldo, tanggal_masuk) VALUES ('$kode','$jumlah_saldo','$tanggal')");
  

	// apakah query simpan berhasil?
	if( $query==TRUE ) {
		// kalau berhasil alihkan ke halaman index.php dengan status=sukses
		header('Location: index.php?status=sukses');
	} else {
		// kalau gagal alihkan ke halaman indek.ph dengan status=gagal
		header('Location: index.php?status=gagal');
	}


} else {
	die("Akses tambah saldo dilarang...");
}
?>
