<?php include("config.php"); ?>


<!DOCTYPE html>
<html>
<head>
	<title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/daftar mahasiswa</title>
</head>

<body>
	<header>
		<h3>Daftar Mahasiswa</h3>
	</header>

	<nav>
		<a href="formdaftar.php">[+] Tambah Baru</a>
	</nav>

	<br>

	<table border="1">
	<thead>
		<tr>
			<th>No</th>
			<th>NIM</th>
			<th>Nama</th>
			<th>Jenis Kelamin</th>
			<th>Asal Daerah</th>
			<th>Delete </th>
			<th>Edit </th>
			<th>Saldo</th>
			<th>Transaksi</th>
			<th>Cek Pengeluaran</th>
			
		</tr>
	</thead>
	<tbody>

		<?php
		$query = pg_query("SELECT * FROM mahasiswa");
				$no = 1;
		// $query = mysqli_query($db, $sql);


		while($siswa = pg_fetch_array($query)){
			echo "<tr>";
			echo "<td>".$no."</td>";
			echo "<td>".$siswa['nim']."</td>";
			echo "<td>".$siswa['nama']."</td>";
			echo "<td>".$siswa['jenis_kelamin']."</td>";
			echo "<td>".$siswa['asal_daerah']."</td>";
			echo "<td>";
			echo "<a href='hapus.php?kode_saldo=".$siswa['kode_saldo']."'>Hapus</a>";
			echo "</td>";
			echo "<td>";
			echo "<a href='formedit.php?kode_saldo=".$siswa['kode_saldo']."'>Edit</a>";
			echo "</td>";
			echo "<td>";
			echo "<a href='formsaldo.php?kode_saldo=".$siswa['kode_saldo']."'>Update </a>";
			echo "</td>";
			echo "<td>";
			echo "<a href='formtransaksi.php?kode_saldo=".$siswa['kode_saldo']."'>Transaksi | </a>";
			echo "<a href='formitem.php?kode_saldo=".$siswa['kode_saldo']."'> Barang </a>";
			echo "</td>";
			echo "<td>";
			echo "<a href='tabelpengeluaran.php?kode_saldo=".$siswa['kode_saldo']."'>Lihat</a>";
			echo "</td>";
			
			echo "</tr>";
			$no++;
			}


		?>

	</tbody>
	</table>

	<p>Total: <?php echo pg_num_rows($query) ?></p>
	<a href="index.php">Back</a>
	</body>
</html>
