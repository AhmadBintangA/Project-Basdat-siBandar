<?php
include("config.php");
session_start();
$id = $_SESSION['id'];
if (is_null($id)) {
	header('location: login.php');
}
$query = pg_query("SELECT * FROM userr where username = '$id'");

$saldo = pg_fetch_array($query, NULL, PGSQL_ASSOC);
?>
<!DOCTYPE html>
<html>

<head>
	<title>Si Bandar</title>
	<link href='gambar-burung-garuda-asli.jpg' rel='shortcut icon'>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<style>
		.mx-auto {
			width: 1000px;
			margin: 50px;
		}

		.mx-auto2 {

			padding-top: 25px;
		}

		.mx-auto3 {
			padding-top: 15px;

		}

		.card {
			margin-top: 20px;

		}
	</style>
</head>

<body>
	<div class="mx-auto">
		<div class="card text-center">
			<div class="card-header fw-bold bg-primary fs-2">
			</div>
			<div class="card-body">
				<h1 class="card-title">Selamat Datang <?= $saldo['nama'] ?>
					<br> Bendahara <?= $saldo['nama_acara'] ?> <?= $saldo['masa_jabatan'] ?> </br>
				</h1>
				<p class="card-text"> Mencatat seluruh pengeluaran dan inventaris dari acara maupun organisasi yang kamu kelola,
					<br> sekarang lebih cepat, aman dan terpercaya.
				</p>
			</div>
		</div>
		<div class="mx-auto">
			<div class="card">
				<div class="card-header bg-primary fs-3">
					Menu
				</div>
				<div class="card-body">
					<div class="row">
						<div class="col-sm-6">
							<div class="card text-center">
								<div class="card-body">
									<h5 class="card-title">Perbarui Saldo</h5>
									<div class="mx-auto3"><a href="formsaldo.php?username=<?= $saldo['username'] ?>" class="btn btn-primary">Lanjut</a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="card text-center">
								<div class="card-body">
									<h5 class="card-title">Catat Pengeluaran</h5>
									<div class="mx-auto3"><a href="formtransaksi.php?username=<?= $saldo['username'] ?>" class="btn btn-primary">Lanjut</a>
									</div>
								</div>
							</div>
						</div>
						<div class="card text-center">
							<div class="card-body">
								<h5 class="card-title">Lihat Rekapan</h5>
								<div class="d-grid gap-2 d-md-flex justify-content-md-center"><a href="viewtr.php?username=<?= $saldo['username'] ?>" class="btn btn-primary">Transaksi</a>
									<div class="d-grid gap-2 d-md-flex justify-content-md-center"><a href="viewinv.php?username=<?= $saldo['username'] ?>" class="btn btn-primary">Inventaris</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<?php if (isset($_GET['status'])) : ?>
				<p>
					<?php
					if ($_GET['status'] == 'sukses') {
						echo "Update saldo berhasil!";
					} else {
						echo "Update saldo gagal!";
					}
					?>
				</p>
			<?php endif; ?>
			<?php if (isset($_GET['status1'])) : ?>
				<p>
					<?php
					if ($_GET['status1'] == 'sukses') {
						echo "Tambah transaksi berhasil!";
					} else {
						echo "Tambah transaksi gagal!";
					}
					?>
				</p>
			<?php endif; ?>
			<div class="mx-auto2">
				<div class="d-grid gap-2 d-md-flex justify-content-md-start"><a class="btn btn-primary" href="logout.php" role="button">Logout</a>
				</div>
			</div>
</body>

</html>