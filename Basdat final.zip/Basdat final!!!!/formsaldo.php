<?php
include("config.php");
session_start();
if (!isset($_SESSION['login'])) {
	header('location:login.php');
}

if (isset($_GET['username'])) {
	$username = $_GET['username'];
	$query = pg_query($db, "SELECT * FROM saldo WHERE username = '$username'");
	$query1 = pg_query($db, "SELECT * FROM userr WHERE username = '$username'");
	$saldo = pg_fetch_array($query, NULL, PGSQL_ASSOC);
	$nganu = pg_fetch_array($query1, NULL, PGSQL_ASSOC);
} else {
	header('Location: index.php');
}


?>
<!DOCTYPE html>
<html>

<head>
	<title>Si Bandar</title>
	<link href='gambar-burung-garuda-asli.jpg' rel='shortcut icon'>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<style>
		.mx-auto {
			width: 1000px;
			margin: 50px;
		}

		.mx-auto2 {
			margin-top: 25px;

		}
	</style>
</head>

<body>
	<div class="mx-auto">
		<div class="card">
			<div class="card-header fw-bold bg-primary fs-2">
				Perbarui Saldo Untuk <?= $nganu['nama_acara'] ?>
			</div>
			<div class="card-body">
				<form action="prosessaldo.php" method="POST">
					<div>
						<input type="hidden" name="username" value="<?= $saldo['username'] ?>" />
					</div>
					<div class="mb-3 row">
						<label for="jumlah_saldo" class="col-sm-2 col-form-label">Jumlah Saldo</label>
						<div class="col-sm-10">
							<input type="number" class="form-control" id="jumlah_saldo" name="jumlah_saldo" placeholder="Masukkan Saldo" value="<?= $saldo['jumlah_saldo'] ?>" />
						</div>
					</div>
					<div class="mb-3 row">
						<label for="tanggal_masuk" class="col-sm-2 col-form-label">Tanggal Masuk</label>
						<div class="col-sm-10">
							<input type="date" class="form-control" id="tanggal_masuk" name="tanggal_masuk" placeholder="dd/mm/yy" value="<?= $saldo['tanggal_masuk'] ?>" />
						</div>
					</div>
					<div class="d-grid gap-2 d-md-flex justify-content-md-end">
						<button class="btn btn-primary" type="Submit" value="Update" name="Save">Update</button>
					</div>
			</div>
		</div>
		</form>
		<div class="mx-auto2">
		<div class="d-grid gap-2 d-md-flex justify-content-md-start"><a class="btn btn-primary" href="index.php" role="button">Kembali</a>
		</div>
</body>

</html>