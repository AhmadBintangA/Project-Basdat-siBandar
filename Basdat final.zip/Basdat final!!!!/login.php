<?php
session_start();
if (isset($_SESSION['login'])) {
    header('location:index.php');
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Si Bandar</title>
    <link href='gambar-burung-garuda-asli.jpg' rel='shortcut icon'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        .mx-auto {
            width: 1000px;
            margin: 50px;
        }

        .mx-auto2 {
            padding-top: 10px;
        }
    </style>
</head>

<body>
<div class="mx-auto">
    <div class="card text-center">
        <div class="card-header fw-bold bg-primary fs-2">
        </div>
        <div class="card-body">
            <h1 class="card-title fw-bold">"Si Bandar" </h1> <h3>Website Pembantu Bendahara</h3>
            <h4 class="card-text fw-bold">Masuklah untuk Merasakan Kemudahan dalam Mencatat Pengeluaran</h4>
        </div>
        <div class="card-header fw-bold bg-primary fs-2">
        </div>
    </div>
    <div class="mx-auto">
        <div class="card">
            <div class="card-header fw-bold bg-primary fs-2">
                Login
            </div>
            <div class="card-body">
                <form action="proseslogin.php" method="POST">
                    <div class="mb-3 row">
                        <label for="username" class="col-sm-2 col-form-label">Username</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan Nama">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="pass" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-10">
                            <input type="password" class="form-control" id="pass" name="pass" placeholder="Masukkan Password">
                        </div>
                    </div>
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button class="btn btn-primary me-md-2" type="Submit" value="login" name="login">Login</button>
                    </div>
                    <div>
                        Belum punya akun? daftar langsung sekarang juga
                    </div>
                    <div class="mx-auto2"><a class="btn btn-primary" href="formregistrasi.php" role="button">Daftar Baru</a>
                    </div>
                </form>
                <?php
                if (isset($_GET['ket']))
                    if ($_GET['ket'] == 'gagal') : ?>
                    <p style="color: red;font-style:italic;">username atau password salah!!!</p>
                <?php endif;

                if (isset($_GET['cek'])) {
                    $cek = $_GET['cek'];
                    if ($cek == 'sukses') {
                        echo 'logout berhasil!';
                    }
                }

                if (isset($_GET['status'])) {
                    $cek = $_GET['status'];
                    if ($cek == 'sukses') {
                        echo 'registrasi baru berhasil! silahkan coba masuk dengan akun baru kamu';
                    }
                }
                ?>
</body>

</html>