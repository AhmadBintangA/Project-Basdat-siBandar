<?php
error_reporting(0);
include("config.php");
if (isset($_GET['username'])) {
    $id = $_GET['username'];
    $query = pg_query($db, "SELECT * FROM userr WHERE username = '$id'");
    $query1 = pg_query($db, "SELECT * FROM saldo WHERE username = '$id'");
    $query3 = pg_query($db, "SELECT * FROM transaksi WHERE username = '$id'");
    $query2 = pg_query($db, "SELECT * FROM item JOIN transaksi ON transaksi.kode_transaksi = item.kode_transaksi WHERE transaksi.username = '$id' AND item.jenis_item = 'awet'");



    $siswa = pg_fetch_array($query, NULL, PGSQL_ASSOC);
    $saldo = pg_fetch_array($query1, NULL, PGSQL_ASSOC);
    $trans = pg_fetch_array($query3, NULL, PGSQL_ASSOC);
} else {
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Si Bandar</title>
    <link href='gambar-burung-garuda-asli.jpg' rel='shortcut icon'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        .mx-auto {
            width: 1000px;
            margin: 50px;
        }

        .mx-auto2 {

            padding-top: 25px;
        }

        .mx-auto3 {
            margin-top: 5px;

        }

        .card 
        {
            margin-top: 20px;

        }
    </style>
</head>

<body>
    <div class="mx-auto">
        <div class="card">
            <div class="card-header fw-bold bg-primary fs-2">
            Daftar Inventaris Yang Dimiliki <?= $siswa['nama_acara']?>
            </div>
            <div class="card-body">
                <table class="table text-center">
                    <thead>
                        <tr>
                            <th scope="col">Tanggal dibeli</th>
                            <th scope="col">Nama Barang</th>
                            <th scope="col">Dimiliki Oleh</th>
                            <th scope="col">Jumlah</th>
                        </tr>
                    <tbody>
                        <?php
                        while ($tr = pg_fetch_array($query2)) {

                        ?>
                            <tr>
                                <th>
                                    <?= $tr['tanggal_transaksi'] ?>
                                </th>
                                <th>
                                    <?= $tr['nama_barang'] ?>
                                </th>
                                <th>
                                    <?= $tr['jabatan'] ?>
                                </th>
                                <th>
                                    <?= $tr['jumlah'] ?>
                                </th>
                            </tr>
                        <?php } ?>
                    </tbody>
                    </thead>
                </table>
                </div>
        </div>
        <div class="mx-auto2"><a class="btn btn-primary" href="index.php" role="button">Kembali</a>
		</div>

</html>