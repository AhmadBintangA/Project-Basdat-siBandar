<?php
    session_start();
    if(isset($_SESSION['login'])){
        header('location:index.php');
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/edit</title>
</head>
<body>
    <header>
    <h1>Si Bandar (Website Pembantu Bendahara)</h1>
    <h4>Silahkan login untuk merasakan kemudahan dalam mencatat pengeluaran</h4>
    <h2>Login</h2>
    </header>

    <form action="proseslogin.php" method="POST">
		<fieldset>
		<p>
			<label for="username">username : </label>
			<input type="text" name="username" ?>
		</p>
		<p>
			<label for="pass">password : </label>
			<input type="password" name="pass" />
		</p>
		<p>
			<input type="submit" value="login" name="login" />
		</p>
        <p>
			Belum punya akun? daftar langsung sekarang juga
		</p>
        <a href="formregistrasi.php">Daftar Baru</a>
		</fieldset>
	</form>
    <?php 
        if (isset($_GET['ket']))
        if ($_GET['ket'] == 'gagal') :?>
            <p style="color: red;font-style:italic;">username atau password salah!!!</p>
        <?php endif; 
    
        if(isset($_GET['cek']))
        {
            $cek = $_GET['cek'];
            if($cek == 'sukses'){
                echo 'logout berhasil!';
            }
        }

        if(isset($_GET['status']))
        {
            $cek = $_GET['status'];
            if($cek == 'sukses'){
                echo 'registrasi baru berhasil! silahkan coba masuk dengan akun baru kamu';
            }
        }
    ?>
</body>
</html>