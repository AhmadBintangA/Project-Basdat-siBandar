<?php
include("config.php");
	session_start();
	if(!isset($_SESSION['login']))
	{
		header('location:login.php');
	}

if (isset($_GET['username'])) {
    $id = $_GET['username'];
	$query = pg_query("SELECT * FROM userr where username = '$id'");
	$saldo = pg_fetch_array($query, NULL, PGSQL_ASSOC);
} else {
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/edit</title>
</head>
<body>
    <header>
    <h3>Catat Pengeluaran untuk <?= $saldo['nama_acara']?> </h3>
    </header>
    <form action="prosestransaksi.php" method="POST">
		<fieldset>
		<p>
			
			<input type="hidden" name="kode_transaksi" value=<?= rand(1, 1000000) ?> placeholder="Masukkan Kode Transaksi" />
		</p>
        <p>
			<label for="nama_pj">Penanggung Jawab : </label>
			<input type="text" name="nama_pj" placeholder="Siapa yang meminta uang" />
		</p>
		<p>
			<label for="jabatan">Divisi : </label>
			<input type="text" name="jabatan" placeholder="Dari divisi..." />
		</p>
		<p>
			<label for="nama_transaksi">Nama Transaksi : </label>
			<input type="text" name="nama_transaksi" placeholder="Masukkan nama transaksi" />
		</p>
        <p>
			<label for="tanggal_transaksi">Tanggal Transaksi : </label>
			<input type="date" name="tanggal_transaksi" placeholder="dd/mm/yy" />
		</p>
		<p>
            <input type="hidden" name="username" value="<?= $id?>"   /> 
        </p>
		<p>
			
			<input type="hidden" name="kode_item" value=<?= rand(1, 1000000) ?> placeholder="Kode Item" />
		</p>
		<p>
			<label for="nama_barang">Nama Barang : </label>
			<input type="text" name="nama_barang" placeholder="Barang yang dibeli" />
		</p>
		<p>
			<label for="jumlah">Jumlah Barang : </label>
			<input type="number" name="jumlah" placeholder="Masukkan Jumlah Barang" />
		</p>		
		<p>
			<label for="jenis_item">Jenis Barang : </label>
			<label><input type="radio" name="jenis_item" value="awet"> Jangka Panjang</label>
			<label><input type="radio" name="jenis_item" value="abis"> Sekali Pakai</label>
	
		</p>
		<p>
			<label for="harga">Harga : </label>
			<input type="number" name="harga" placeholder="Uang yang Anda keluarkan" />
		</p>
		
		<p>
			<input type="submit" value="Tambah" name="Tambah" />
		</p>
		
		</fieldset>
	
	</form>
<a href="index.php">Back</a>
</body>
</html>