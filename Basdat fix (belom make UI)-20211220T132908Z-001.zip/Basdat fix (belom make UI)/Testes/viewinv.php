<?php
error_reporting(0);
include("config.php");
if (isset($_GET['username'])) {
    $id = $_GET['username'];
    $query = pg_query($db, "SELECT * FROM userr WHERE username = '$id'");
    $query1 = pg_query($db, "SELECT * FROM saldo WHERE username = '$id'");
    $query3 = pg_query($db, "SELECT * FROM transaksi WHERE username = '$id'");
    $query2 = pg_query($db, "SELECT * FROM item JOIN transaksi ON transaksi.kode_transaksi = item.kode_transaksi WHERE transaksi.username = '$id' AND item.jenis_item = 'awet'");
 
    
    
    $siswa = pg_fetch_array($query, NULL, PGSQL_ASSOC);
    $saldo = pg_fetch_array($query1, NULL, PGSQL_ASSOC);
    $trans = pg_fetch_array($query3, NULL, PGSQL_ASSOC);
    

   
} else {
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/daftar mahasiswa</title>
</head>

<body>
	<header>
		<h3>Daftar Inventaris yang dimiliki <?= $siswa['nama_acara']?> </h3>
	</header>

    <table>
        <tr>
        
        </tr>
    </table>
    <table border="1">
	<thead>
		<tr>
			<th>Tanggal dibeli</th>
       		<th>Nama Barang</th>
			<th>Dimiliki Oleh</th>
			<th>Jumlah</th>
		</tr>
	</thead>
    <tbody>
        <?php
            while($tr = pg_fetch_array($query2)){

        ?>
        <tr>
            <th>
                <?= $tr['tanggal_transaksi'] ?>
            </th>
            <th>
                <?= $tr['nama_barang'] ?>
            </th>
            <th>
                <?= $tr['jabatan'] ?>
            </th>
            <th>
                <?= $tr['jumlah'] ?>
            </th>
        </tr>
        <?php }?>
    </tbody>
</table>
	<a href="index.php">Back</a>
</body>
</html>