<?php
include("config.php");
// cek apakah tombol masuk sudah diklik atau blum?
if (isset($_POST['Save'])) {
		$kode = $_POST['username'] ;
    	$saldo = $_POST['jumlah_saldo'];
		$tgl = $_POST['tanggal_masuk'];
		// buat query
    
		$q = "UPDATE saldo SET username='$kode', jumlah_saldo='$saldo', tanggal_masuk='$tgl' 
		WHERE username = '$kode'";
		$query = pg_query($q);
		// apakah query simpan berhasil?
		if( $query) {
			// kalau berhasil alihkan ke halaman index.php dengan status=sukses
			header('Location: index.php?status=sukses');
		} else {
			// kalau gagal alihkan ke halaman indek.ph dengan status=gagal
			header('Location: index.php?status=gagal');
		}

}

else {
	die("Akses update saldo dilarang...");
}


