<?php
include("config.php");
	session_start();
	if(!isset($_SESSION['login']))
	{
		header('location:login.php');
	}

if (isset($_GET['kode_saldo'])) {
    $id = $_GET['kode_saldo'];
    $query = pg_query($db, "SELECT * FROM mahasiswa WHERE kode_saldo = '$id'");
    $siswa = pg_fetch_array($query, NULL, PGSQL_ASSOC);
} else {
    header('Location: daftarpegawai.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Pegawai/edit</title>
</head>
<body>
    <header>
        <h3>Formulir Edit</h3>
    </header>
    <form action="prosesedit.php" method="POST">
        <fieldset>
            <p> 
                <input type = "hidden" name ="kode_saldo" value="<?=$siswa['kode_saldo']?>"/>
            </p>
            <p>
                <label for="nim">NIP: </label>
                <input type="text" name="nim" placeholder="Masukkan NIP" value="<?= $siswa['nim'] ?>" />
            </p>
            <p>
                <label for="nama">Nama: </label>
                <input type="text" name="nama" placeholder="Masukkan Nama Lengkap" value="<?= $siswa['nama'] ?>" />
            </p>
            <p>
                <label for="jenis_kelamin">Jenis Kelamin: </label>
                <label><input type="radio" name="jenis_kelamin" value="laki-laki" 
                <?php
                    if ($siswa['jenis_kelamin'] == 'laki-laki') {
                        echo "checked";
                    }
                ?>> Laki-laki</label>
                <label><input type="radio" name="jenis_kelamin" 
                <?php
                    if ($siswa['jenis_kelamin'] == 'perempuan') {
                        echo "checked";
                    }
                   ?> value="perempuan"> Perempuan</label>
            </p>
            <p>
                <label for="asal_daerah">Asal Daerah: </label>
                <input type="text" name="asal_daerah" placeholder="nama sekolah" value="<?= $siswa['asal_daerah'] ?>" />
            </p>
            <p>
                <input type="submit" value="Edit" name="Masuk" />
            </p>
        </fieldset>
    </form>
    <a href="daftarpegawai.php">Back</a>
</body>
</html>