<?php
include("config.php");
if(isset($_GET['kode_saldo'])){
    $id = $_GET['kode_saldo'];

    $query = pg_query("DELETE FROM mahasiswa WHERE kode_saldo='$id'");
    if($query){
        $query1 = pg_query("DELETE FROM saldo WHERE kode_saldo='$id'");
        $query2 = pg_query("DELETE FROM transaksi WHERE kode_saldo='$id'");
        $query3 = pg_query("DELETE FROM item WHERE kode_saldo='$id'");
        header('Location: daftarpegawai.php');
    }
    else{
        die("gagal mengahpus...");
    }
} else{
    die("akses dilarang...");
}
?>