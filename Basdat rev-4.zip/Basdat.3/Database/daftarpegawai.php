
<!DOCTYPE html>
<html>
<head>
	<title>Hedon(Hemat Dong)|Pencatat Pengeluaran Pegawai/daftar Pegawai</title>
</head>

<body>
	<header>
		<h3>Daftar Pegawai</h3>
	</header>

	<nav>
		<a href="formdaftar.php">[+] Tambah Baru</a>
	</nav>

	<br>

	<table border="1">
	<thead>
		<tr>
			<th>No</th>
			<th>NIP</th>
			<th>Nama</th>
			<th>Jenis Kelamin</th>
			<th>Asal Daerah</th>
			<th>Delete </th>
			<th>Edit </th>
			<th>Saldo</th>
			<th>Transaksi</th>
			<th>Cek Pengeluaran</th>
			
		</tr>
	</thead>
	<tbody>

		<?php
		$query = pg_query("SELECT * FROM userr");
				$no = 1;
		// $query = mysqli_query($db, $sql);


		while($siswa = pg_fetch_array($query)){
			echo "<tr>";
			echo "<td>".$no."</td>";
			echo "<td>".$siswa['nim']."</td>";
			echo "<td>".$siswa['nama']."</td>";
			echo "<td>".$siswa['jenis_kelamin']."</td>";
			echo "<td>".$siswa['asal_daerah']."</td>";
			echo "<td>";
			echo "<a href='hapus.php?kode_saldo=".$siswa['kode_saldo']."'>Hapus</a>";
			echo "</td>";
			echo "<td>";
			echo "<a href='formedit.php?kode_saldo=".$siswa['kode_saldo']."'>Edit</a>";
			echo "</td>";
			echo "<td>";
			echo "<a href='for.php?kode_saldo=".$siswa['kode_saldo']."'>Update </a>";
			echo "</td>";
			echo "<td>";
			echo "<a href='formtransaksi.php?kode_saldo=".$siswa['kode_saldo']."'>Transaksi | </a>";
			echo "<a href='formitem.php?kode_saldo=".$siswa['kode_saldo']."'> Barang </a>";
			echo "</td>";
			echo "<td>";
			echo "<a href='tabelpengeluaran.php?kode_saldo=".$siswa['kode_saldo']."'>Lihat</a>";
			echo "</td>";
			
			echo "</tr>";
			$no++;
			}


		?>

	</tbody>
	</table>

	<p>Total: <?php echo pg_num_rows($query) ?></p>
	<a href="index.php">Back</a>
	<?php if(isset($_GET['status'])): ?>
	<p>
		<?php
			if($_GET['status'] == 'sukses'){
				echo "Berhasil masukkan item!!!";
			} else {
				echo "Gagal masukkan item!!!";
			}
		?>
	</p>
	<?php endif; ?>

	</body>
</html>
