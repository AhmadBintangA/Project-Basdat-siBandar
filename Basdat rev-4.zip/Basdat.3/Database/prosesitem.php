<?php
include("config.php");
// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['OK'])){
    
    //ambil data dari formulir
        $kodeit = $_POST['kode_item'] ;
        $namait = $_POST['nama_barang'];
        $harga = $_POST['harga'];
        $id = $_POST['kode_transaksi'];
        $kode = $_POST['kode_saldo'];
	

	    // buat query
        $query = pg_query("INSERT INTO item(kode_item, nama_barang,harga,kode_saldo,kode_transaksi) VALUES ('$kodeit','$namait','$harga','$kode','$id')");
	    // apakah query simpan berhasil?
	    if($query) {
		    // kalau berhasil alihkan ke halaman index.php dengan status=sukses
		    header('Location: daftarpegawai.php?status=sukses');
	    } else {
		    // kalau gagal alihkan ke halaman indek.php dengan status=gagal
		    header('Location: daftarpegawai.php?status=gagal');
    	}
    

} 
else {
	die("Akses tambah item dilarang...");
}
?>

