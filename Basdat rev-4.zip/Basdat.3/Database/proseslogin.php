<?php
    session_start();
    include("config.php");
    // cek apakah tombol login sudah diklik atau blum?
    if(isset($_POST['login'])){

	// ambil data dari formulir
	$username = $_POST['username'];
	$pw = $_POST['pass'];

    $hasil = pg_query("select * from userr where username = '$username' AND pass ='$pw'");
    $row = pg_num_rows($hasil);
    if($row == 1) {
        $_SESSION['login'] = true;
        $_SESSION['id'] = $username;
    
        header('location: index.php');
    }
    else header('location: login.php?ket=gagal');
    }
?>
