<?php
	include("config.php");
	session_start();
	if(!isset($_SESSION['login']))
	{
		header('location:login.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Hedon(Hemat Dong)|Pencatat Pengeluaran Pegawai</title>
</head>

<body>
	<header>
		<h3>Formulir Pegawai</h3>
	</header>

	<form action="prosespendaftaran.php" method="POST">
		<fieldset>
		<p>
			<label for="nim">NIP: </label>
			<input type="text" name="nim" placeholder="Masukkan NIP" />
		</p>
		<p>
			<label for="nama">Nama: </label>
			<input type="text" name="nama" placeholder="Masukkan Nama Lengkap" />
		</p>
		<p>
			<label for="jenis_kelamin">Jenis Kelamin: </label>
			<label><input type="radio" name="jenis_kelamin" value="laki-laki"> Laki-laki</label>
			<label><input type="radio" name="jenis_kelamin" value="perempuan"> Perempuan</label>
		</p>
		<p>
			<label for="asal_daerah">Asal Daerah: </label>
			<input type="text" name="asal_daerah" placeholder="Asal Daerah" />
		</p>
		<p>
			<label for="kode_saldo">Kode Saldo: </label>
			<input type="text" name="kode_saldo" placeholder="Kode Anda 10 digit" />
		</p>
		<p>
			<input type="submit" value="Masuk" name="Masuk" />
		</p>
		</fieldset>
	</form>
	<a href="index.php">Back</a>
</body>
</html>
