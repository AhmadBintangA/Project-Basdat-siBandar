<?php
include("config.php");
	session_start();
	if(!isset($_SESSION['login']))
	{
		header('location:login.php');
	}

if (isset($_GET['username'])) {
    $username = $_GET['username'];
    $query = pg_query($db, "SELECT * FROM saldo WHERE username = '$username'");
    $saldo = pg_fetch_array($query, NULL, PGSQL_ASSOC);
} else {
    header('Location: index.php');
}


?>
<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/saldo</title>
</head>
<body>
    <header>
    <h3>Formulir Saldo</h3>
    </header>
    <form action="prosessaldo.php" method="POST">
		<fieldset>
		<p> 
			<input type="hidden" name="username" value="<?= $saldo['username'] ?>"   />
		</p>
		<p>
			<label for="jumlah_saldo">Jumlah Saldo : </label>
			<input type="number" name="jumlah_saldo" placeholder="Masukkan saldo" value="<?= $saldo['jumlah_saldo'] ?>" />
		</p>
		<p>
			<label for="tanggal_masuk">Tanggal Masuk : </label>
			<input type="date" name="tanggal_masuk" placeholder="dd/mm/yy" value="<?= $saldo['tanggal_masuk'] ?>" />
		</p>
		<p>
			<input type="submit" value="Update" name="Save" />
		</p>
		</fieldset>
	</form>
<a href="index.php">Back</a>
</body>
</html>