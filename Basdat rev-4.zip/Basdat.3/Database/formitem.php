<?php
include("config.php");
	session_start();
	if(!isset($_SESSION['login']))
	{
		header('location:login.php');
	}
if (isset($_GET['kode_saldo'])) {
	$id = $_GET['kode_saldo'];
	$query = pg_query($db, "SELECT * FROM transaksi WHERE kode_saldo = '$id'");
    $siswa = pg_fetch_array($query, NULL, PGSQL_ASSOC);
	if(isset($_GET['kode_transaksi'])){
	$getah = $_POST['kode_transaksi'];
	$query = pg_query($db, "SELECT * FROM transaksi WHERE kode_saldo = '$id'");
    $geta = pg_fetch_array($query, NULL, PGSQL_ASSOC);
	var_dump($geta['kode_transaksi']);
	}
} 
else {
    header('Location: daftarpegawai.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/edit</title>
</head>
<body>
    <header>
    <h3>Formulir Item si hedon</h3>
    </header>
    <form action="prosesitem.php" method="POST">
		<fieldset>
        <p>
			<input type = "hidden" name ="kode_transaksi" value="<?=$siswa['kode_transaksi']?>"/>
        </p>
		<p>
			<input type = "hidden" name ="kode_saldo" value="<?=$siswa['kode_saldo']?>"/>
        </p>
		<p>
			<label for="kode_item"> Kode Item : </label>
			<input type="text" name="kode_item" placeholder="Masukkan Kode Item" />
		</p>
        <p>
			<label for="nama_barang">Nama Barang : </label>
			<input type="text" name="nama_barang" placeholder="Masukkan Nama Barang" />
		</p>
        <p>
			<label for="harga">Harga : </label>
			<input type="number" name="harga" placeholder="Masukkan harga" />
		</p>
		<p>
			<input type="submit" value="OK" name="OK" />
		</p>
		</fieldset>
	</form>
<a href="daftarpegawai.php">Back</a>
</body>
</html>