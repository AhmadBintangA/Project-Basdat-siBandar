<?php
include("config.php");
if (isset($_GET['kode_saldo'])) {
    $id = $_GET['kode_saldo'];
    $query = pg_query($db, "SELECT * FROM mahasiswa WHERE kode_saldo = '$id'");
    $query1 = pg_query($db, "SELECT * FROM saldo WHERE kode_saldo = '$id'");
    $query2 = pg_query($db, "SELECT * FROM transaksi WHERE kode_saldo = '$id'");
    
    $siswa = pg_fetch_array($query, NULL, PGSQL_ASSOC);
    $saldo = pg_fetch_array($query1, NULL, PGSQL_ASSOC);
    $trans = pg_fetch_array($query2, NULL, PGSQL_ASSOC);
    
    
   
} else {
    header('Location: daftarpegawai.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/daftar mahasiswa</title>
</head>

<body>
	<header>
		<h3>Tabel Pengeluaran</h3>
	</header>
    <table>
        <tr>
        <th>
            Nama: <?= $siswa['nama'] ?>
        </th>
        </tr>
        <tr>
        <th>
            NIM:<?= $siswa['nim'] ?>
        </th>
        </tr>
        <tr>
        <th>
            Jenis Kelamin:<?= $siswa['jenis_kelamin'] ?>
        </th>
        </tr>
        <tr>
        <th>
            Asal Daerah:<?= $siswa['asal_daerah'] ?>
        </th>
        </tr>
        <tr>
        <th>
            Saldo:<?= $saldo['jumlah_saldo'] ?>
        </th>
        </tr>
    </table>
    <table border="1">
	<thead>
		<tr>
			<th>Tanggal Transaksi</th>
			<th>Kode Transaksi</th>
			<th>Nama Barang</th>
			<th>Harga</th>
		</tr>
	</thead>
    <tbody>
        <?php
            $query2 = pg_query($db, "SELECT t.kode_saldo, t.tanggal_transaksi, t.kode_transaksi, i.kode_saldo, i.nama_barang,i.harga
            FROM transaksi AS t JOIN item AS i ON t.kode_transaksi = i.kode_transaksi");
            $total = 0;
            while($tr = pg_fetch_array($query2)){
                if ($id == $tr['kode_saldo']){
                $total += $tr['harga'];
        ?>
        <tr>
            <th>
                <?= $tr['tanggal_transaksi'] ?>
            </th>
            <th>
                <?= $tr['kode_transaksi'] ?>
            </th>
            <th>
                <?= $tr['nama_barang'] ?>
            </th>
            <th>
                <?= $tr['harga'] ?>
            </th>
        </tr>
        <?php } }?>
    </tbody>
</table>
	<p>Total Harga: <?= $total ?> 
    </p>
    <p>
        Sisa Saldo: <?= $saldo['jumlah_saldo'] - $total ?>
    </p>
	<a href="daftarpegawai.php">Back</a>
</body>
</html>
