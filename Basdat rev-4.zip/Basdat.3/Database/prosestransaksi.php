<?php
include("config.php");
// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['Tambah'])){

    
    //ambil data dari formulir
		$kodetr = $_POST['kode_transaksi'] ;
		$pj = $_POST['nama_pj'];
		$jabatan = $_POST['jabatan'];
        $namatr = $_POST['nama_transaksi'];
        $tanggaltr = $_POST['tanggal_transaksi'];
        $id = $_POST['username'];
		$harga = $_POST['harga'];
		$kode = $_POST['kode_item'];
		$namabr = $_POST['nama_barang'];
		$jenis = $_POST['jenis_item'];
	
		
	    // buat query
        $query = pg_query("INSERT INTO transaksi(kode_transaksi, nama_pj, jabatan,nama_transaksi,tanggal_transaksi,username) VALUES ('$kodetr','$pj','$jabatan','$namatr','$tanggaltr','$id')");
	    // apakah query simpan berhasil?
	    if( $query['jenis_item'] == 'awet') {
			$query1 = pg_query("INSERT INTO item(kode_transaksi, kode_item, nama_barang, harga,username, jenis_item) VALUES ('$kodetr','$kode','$namabr','$harga','$id','$jenis')");
		    // kalau berhasil alihkan ke halaman index.php dengan status=sukses
		    header('Location: index.php?status1=sukses');
	    } else {
		    // kalau gagal alihkan ke halaman indek.ph dengan status=gagal
		    header('Location: index.php?status1=gagal');
    	}
    

} 
else {
	die("Akses tambah transaksi dilarang...");
}
?>

