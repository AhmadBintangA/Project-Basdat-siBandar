

<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/saldo</title>
</head>
<body>
    <header>
    <h3>Formulir Saldo</h3>
    </header>
    <form action="prosessaldo.php" method="POST">
		<fieldset>
		<p> 
			<input type="hidden" name="username"   />
		</p>
		<p>
			<label for="jumlah_saldo">Jumlah Saldo : </label>
			<input type="number" name="jumlah_saldo" placeholder="Masukkan saldo"  />
		</p>
		<p>
			<label for="tanggal_masuk">Tanggal Masuk : </label>
			<input type="date" name="tanggal_masuk" placeholder="dd/mm/yy" />
		</p>
		<p>
			<input type="submit" value="Update" name="Save" />
		</p>
		</fieldset>
	</form>
<a href="index.php">Back</a>
</body>
</html>