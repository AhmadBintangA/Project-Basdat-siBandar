<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/edit</title>
</head>
<body>
    <header>
    <h2>Login</h2>
    </header>

    <form action=" " method="POST">
		<fieldset>
		<p>
			<label for="username">username : </label>
			<input type="text" name="username" ?>
		</p>
		<p>
			<label for="pass">password : </label>
			<input type="password" name="pass" />
		</p>
		<p>
			<input type="submit" value="login" name="login" />
		</p>
        <a href="formregistrasi.php">Daftar Baru</a>
		</fieldset>
	</form>
    <?php 
        if (isset($_GET['ket']))
        if ($_GET['ket'] == 'gagal') :?>
            <p style="color: red;font-style:italic;">username atau password salah!!!</p>
        <?php endif; 
    
        if(isset($_GET['cek']))
        {
            $cek = $_GET['cek'];
            if($cek == 'sukses'){
                echo 'logout berhasil!!!';
            }
        }

        if(isset($_GET['status']))
        {
            $cek = $_GET['status'];
            if($cek == 'sukses'){
                echo 'registrasi baru berhasil!!!';
            }
        }
    ?>
</body>
</html>