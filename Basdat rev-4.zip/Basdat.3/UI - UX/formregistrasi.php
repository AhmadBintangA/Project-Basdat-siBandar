
<!DOCTYPE html>
<html>
<head>
	<title>Hedon(Hemat Dong)|Pencatat Pengeluaran Pegawai</title>
</head>

<body>
	<header>
		<h3>Formulir Registrasi Baru</h3>
	</header>

	<form action="prosesregistrasi.php" method="POST">
		<fieldset>
		<p>
			<label for="username">Username: </label>
			<input type="text" name="username" placeholder="Masukkan username" />
		</p>
		<p>
			<label for="pass">Password: </label>
			<input type="password" name="pass" />
		</p>
        <p>
			<label for="nama">Nama: </label>
			<input type="text" name="nama" placeholder="Masukkan nama" />
		</p>
		<p>
			<label for="nama_acara">Nama Acara/Organisasi: </label>
			<input type="text" name="nama_acara" />
		</p>
		<p>
			<label for="jumlah_saldo">Jumlah Saldo: </label>
			<input type="number" name="jumlah_saldo" placeholder="Masukkan saldo" />
		</p>
        <p>
			<label for="tanggal_masuk">Tanggal Masuk: </label>
			<input type="date" name="tanggal_masuk" />
		</p>
		<p>
			<input type="submit" value="Regist" name="Regist" />
		</p>
		</fieldset>
	</form>
	<a href="index.php">Back</a>
</body>
</html>
