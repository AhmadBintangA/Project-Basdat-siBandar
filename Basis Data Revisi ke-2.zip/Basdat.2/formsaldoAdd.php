<?php
include("config.php");
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = pg_query($db, "SELECT * FROM mahasiswa WHERE id = $id");
    $siswa = pg_fetch_array($query, NULL, PGSQL_ASSOC);
} else {
    header('Location: daftarsiswa.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/edit</title>
</head>
<body>
    <header>
    <h3>Formulir saldo Add si hedon</h3>
    </header>
    <form action="prosessaldoTambah.php" method="POST">
		<fieldset>
		<p> 
			<input type="hidden" name="kode_saldo" value="<?= $saldo['kode_saldo'] ?>"   />
		</p>
		<p> 
			<input type="hidden" name="kode_saldo" value="<?= $siswa['kode_saldo'] ?>"   />
		</p>
		<p>
			<label for="jumlah_saldo">Jumlah Saldo : </label>
			<input type="number" name="jumlah_saldo" placeholder="Masukkan saldo" />
		</p>
		<p>
			<label for="tanggal_masuk">Tanggal Masuk : </label>
			<input type="date" name="tanggal_masuk" placeholder="dd/mm/yy" />
		</p>
		<p>
			<input type="submit" value="Save" name="Save" />
		</p>
		</fieldset>
	</form>
<a href="daftarsiswa.php">Back</a>
</body>
</html>