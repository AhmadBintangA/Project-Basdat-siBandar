<?php
include("config.php");
// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['Tambah'])){
    
    //ambil data dari formulir
        $kodetr = $_POST['kode_transaksi'] ;
        $namatr = $_POST['nama_transaksi'];
        $tanggaltr = $_POST['tanggal_transaksi'];
        $id = $_POST['kode_saldo'];
	

	    // buat query
        $query = pg_query("INSERT INTO transaksi(kode_transaksi, nama_transaksi,tanggal_transaksi,kode_saldo) VALUES ('$kodetr','$namatr','$tanggaltr','$id')");
	    // apakah query simpan berhasil?
	    if( $query) {
		    // kalau berhasil alihkan ke halaman index.php dengan status=sukses
		    header('Location: daftarsiswa.php?status=sukses');
	    } else {
		    // kalau gagal alihkan ke halaman indek.ph dengan status=gagal
		    header('Location: index.php?status=gagal');
    	}
    

} 
else {
	die("Akses tambah transaksi dilarang...");
}
?>

