<?php
include("config.php");
if (isset($_GET['kode_saldo'])) {
    $id = $_GET['kode_saldo'];
    $query = pg_query($db, "SELECT * FROM saldo WHERE kode_saldo = '$id'");
    $saldo = pg_fetch_array($query, NULL, PGSQL_ASSOC);
} else {
    header('Location: daftarsiswa.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hedon(Hemat Dong)|Pencatat Pengeluaran Mahasiswa/edit</title>
</head>
<body>
    <header>
    <h3>Formulir saldo si hedon</h3>
    </header>
    <form action="prosessaldo.php" method="POST">
		<fieldset>
		<p> 
			<input type="hidden" name="kode_saldo" value="<?= $saldo['kode_saldo'] ?>"   />
		</p>
		<p>
			<label for="jumlah_saldo">Jumlah Saldo : </label>
			<input type="number" name="jumlah_saldo" placeholder="Masukkan saldo" value="<?= $saldo['jumlah_saldo'] ?>" />
		</p>
		<p>
			<label for="tanggal_masuk">Tanggal Masuk : </label>
			<input type="date" name="tanggal_masuk" placeholder="dd/mm/yy" value="<?= $saldo['tanggal_masuk'] ?>" />
		</p>
		<p>
			<input type="submit" value="Update" name="Save" />
		</p>
		</fieldset>
	</form>
<a href="daftarsiswa.php">Back</a>
</body>
</html>