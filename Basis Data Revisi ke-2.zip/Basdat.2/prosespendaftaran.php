<?php
include("config.php");
// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['Masuk'])){

	// ambil data dari formulir
	$NIM = $_POST['nim'];
	$nama = $_POST['nama'];
	$jk = $_POST['jenis_kelamin'];
	$asal = $_POST['asal_daerah'];
	$kode = $_POST['kode_saldo'];
	
	

	// buat query
  $query = pg_query("INSERT INTO mahasiswa(nim, nama, jenis_kelamin, asal_daerah,kode_saldo) VALUES ('$NIM', '$nama', '$jk', '$asal','$kode')");
  if($query){
	$query1 = pg_query("INSERT INTO saldo(kode_saldo,jumlah_saldo,tanggal_masuk) VALUES ('$kode', 0, NULL)");
	header('Location: daftarsiswa.php?status=sukses');
  }


	// apakah query simpan berhasil
		// kalau berhasil alihkan ke halaman index.php dengan status=sukses
	else {
		// kalau gagal alihkan ke halaman indek.ph dengan status=gagal
		header('Location: index.php?status=gagal');
	}


} else {
	die("Akses dilarang...");
}
?>
